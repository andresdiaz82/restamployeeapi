package com.sacti.rimla.medic.dto;

import com.sacti.rimla.medic.entities.MainEntity;

public interface MainDTO {

	String toString();
	
	MainEntity toEntity();
}
