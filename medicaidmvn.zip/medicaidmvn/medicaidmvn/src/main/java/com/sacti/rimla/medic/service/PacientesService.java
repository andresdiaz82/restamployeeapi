package com.sacti.rimla.medic.service;

public interface PacientesService {

}
