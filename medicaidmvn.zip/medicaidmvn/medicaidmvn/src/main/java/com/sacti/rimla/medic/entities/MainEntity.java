package com.sacti.rimla.medic.entities;

import com.sacti.rimla.medic.dto.MainDTO;

public interface MainEntity {

	MainDTO toDTO();
	
}
