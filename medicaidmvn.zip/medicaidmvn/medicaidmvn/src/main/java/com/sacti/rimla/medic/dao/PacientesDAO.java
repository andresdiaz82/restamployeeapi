package com.sacti.rimla.medic.dao;

import com.sacti.rimla.medic.entities.Pacientes;

public interface PacientesDAO {

	public Pacientes insertaPaciente(Pacientes paciente);
	
}
